# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.13",
        python_install_dir=r"/usr/local/lib/python3.13/site-packages/",
        python_path=r"/data/data/com.termux/files/home/FederateWorkspace/WellsiteTools/Dvenv/bin/python3.13",

        # Package versions
        contourpy_version="1.3.3",
        meson_version="1.11.1",
        mesonpy_version="0.20.0",
        pybind11_version="3.0.4",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/data/data/com.termux/files/usr/tmp/pip-install-vd2vudtt/contourpy_4b854bc21bb740bd877ad56dec6d88b8/.mesonpy-lxfh1wq1/lib/contourpy/util",
        source_dir=r"/data/data/com.termux/files/usr/tmp/pip-install-vd2vudtt/contourpy_4b854bc21bb740bd877ad56dec6d88b8/lib/contourpy/util",
        cross_build="False",

        # Build options
        build_options=r"-Dbuildtype=release -Db_ndebug=if-release -Db_vscrt=md -Dvsenv=true --native-file=/data/data/com.termux/files/usr/tmp/pip-install-vd2vudtt/contourpy_4b854bc21bb740bd877ad56dec6d88b8/.mesonpy-lxfh1wq1/meson-python-native-file.ini",
        buildtype="release",
        cpp_std="c++17",
        debug="False",
        optimization="3",
        vsenv="True",
        b_ndebug="if-release",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="clang",
        compiler_version="21.1.8",
        linker_id="ld.lld",
        compile_command="c++",

        # Host machine
        host_cpu="aarch64",
        host_cpu_family="aarch64",
        host_cpu_endian="little",
        host_cpu_system="android",

        # Build machine, same as host machine if not a cross_build
        build_cpu="aarch64",
        build_cpu_family="aarch64",
        build_cpu_endian="little",
        build_cpu_system="android",
    )
