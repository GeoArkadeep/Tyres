"""Dummy sqlite-vec implementation for bypassing platform constraints."""

def load(*args, **kwargs):
    """Stub for sqlite_vec.load()"""
    pass

def loadable_path() -> str:
    """Stub for sqlite_vec.loadable_path()"""
    return ""
